Usage
=====

.. _installation:

Installation
------------

To use pyRBM, first install it using pip:

.. code-block:: console

   (.venv) $ pip install pyRBM
