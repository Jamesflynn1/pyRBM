Welcome to the pyRBM documentation!
===================================

**pyRBM** is a Python library to enable the construction and simulation of rules based models.


Check out the :doc:`Usage` section for further information, including
how to :ref:`installation` the project.

.. note::

   This project is under active development.

Contents
--------

.. toctree::
   Overview
   Usage
   pyRBM
